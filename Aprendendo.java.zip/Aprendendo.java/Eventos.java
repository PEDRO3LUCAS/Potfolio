public class Evento {

    private int codigo;
    private String nome;
    private String local;
    private double valorInscricao;
    private int vagas;
    private int cargaHoraria;

    public Evento(int codigo, String nome, String local, double valorInscricao, int vagas, int cargaHoraria) {
        this.codigo = codigo;
        this.nome = nome;
        this.local = local;
        this.valorInscricao = valorInscricao;
        this.vagas = vagas;
        this.cargaHoraria = cargaHoraria;
    }

    public void exibirInformacoes() {
        System.out.println("----------------------------");
        System.out.println("Código: " + codigo);
        System.out.println("Nome: " + nome);
        System.out.println("Local: " + local);
        System.out.println("Valor da inscrição: R$ " + valorInscricao);
        System.out.println("Quantidade de vagas: " + vagas);
        System.out.println("Carga horária: " + cargaHoraria + " horas");
    }

    public void verificarVagas() {
        if (vagas > 0) {
            System.out.println("Há vagas disponíveis para inscrição.");
        } else {
            System.out.println("Não há vagas disponíveis.");
        }
    }

    public void situacaoVagas() {

        if (vagas < 10) {
            System.out.println("Situação: Últimas vagas");
        } else if (vagas >= 10 && vagas <= 30) {
            System.out.println("Situação: Vagas moderadas");
        } else {
            System.out.println("Situação: Muitas vagas disponíveis");
        }

    }

    public void verificarDesconto() {

        if (valorInscricao > 300) {
            double desconto = valorInscricao * 0.10;
            double valorFinal = valorInscricao - desconto;

            System.out.println("Evento possui desconto de 10%.");
            System.out.println("Valor com desconto: R$ " + valorFinal);

        } else {
            System.out.println("Evento não possui desconto.");
        }

    }

    public int getVagas() {
        return vagas;
    }

}