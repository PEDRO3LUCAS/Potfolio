import javax.swing.JOptionPane;

public class Principal {

    public static void main(String[] args) {

        Evento[] eventos = new Evento[3];

        for (int i = 0; i < 3; i++) {

            int codigo = Integer.parseInt(JOptionPane.showInputDialog("Digite o código do evento:"));

            String nome = JOptionPane.showInputDialog("Digite o nome do evento:");

            String local = JOptionPane.showInputDialog("Digite o local do evento:");

            double valor = Double.parseDouble(JOptionPane.showInputDialog("Digite o valor da inscrição:"));

            int vagas = Integer.parseInt(JOptionPane.showInputDialog("Digite a quantidade de vagas disponíveis:"));

            int carga = Integer.parseInt(JOptionPane.showInputDialog("Digite a carga horária do evento:"));

            eventos[i] = new Evento(codigo, nome, local, valor, vagas, carga);

            if (vagas < 10) {
                JOptionPane.showMessageDialog(
                        null,
                        "ALERTA!\nO evento está com as últimas vagas disponíveis!",
                        "Últimas vagas",
                        JOptionPane.WARNING_MESSAGE);
            }

        }

        System.out.println("========== EVENTOS CADASTRADOS ==========");

        for (int i = 0; i < 3; i++) {

            eventos[i].exibirInformacoes();
            eventos[i].verificarVagas();
            eventos[i].situacaoVagas();
            eventos[i].verificarDesconto();

            System.out.println();

        }

    }

}